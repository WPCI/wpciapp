<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <title>Women program for counsil iniative non governmental organization</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/logo.jpg" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Remember
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/remember-free-multipurpose-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:contact@example.com">contact@example.com</a></i>
        <i class="bi bi-phone d-flex align-items-center ms-4"><span>+1 5589 55488 55</span></i>
      </div>
      <div class="social-links d-none d-md-flex align-items-center">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex justify-content-between">

      <div class="logo">
        <h1 class="text-light"><a href="index.html"><img src="assets/img/logo.jpg" ></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#services">Services</a></li>
          <li><a class="nav-link scrollto " href="#portfolio">Portfolio</a></li>
          <li><a class="nav-link scrollto" href="#team">Team</a></li>
          <li class="dropdown"><a href="#"><span>Drop Down</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="#">Drop Down 2</a></li>
              <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container" data-aos="fade-up">
      <h1 style="text-light: centre">Welcome to Women Program For Counsel Initiative </h1>

      <h2>WPCI.NGO  WE ARE SAVE GUIDER </h2>
      <h3 style="color: white;">We value humanity and increase life expectancy</h3>
      <a href="#about" class="btn-get-started scrollto">Get Started</a>
        <h4>/h4>
        <h5></h5>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!--==== DESCRIPTION STARTS=====--->

      <div class="home">
             <h2 style="text-light:centre">Women Program For Counsel Initiative (WPCI NGO)</h2>
                <p style=" margin: 10PX; text-align: justify; font-size: 17px;"> 
                  Women Program for Counsel Initiative (WPCI) is charitable non-governmental organization. We are save guiders, working towards elimination and eradication of problems that brings about suffering and dead of vulnerable woman, youths and infants in the communities.

                 WPCI, is legal, registered by south Sudan Relief And Rehabilitation commission (SSRRC) and legal justice in July 2022. WPCI, was found in July 2017 , based in juba south Sudan. WPCI is known of it's conviction in giving essential programs and projects to transform and save many lives in the society.

                We are helping community in few areas of intervention or service like; Health and nutrition, child protection and GBV, sex and formal education, women and youths empowerment, hence food agriculture and livelihood.

               We are volunteering due to lack of resources and manpower. WPCI, is operating through direction and programs strategic plan by Top management to middle management to first line management.

               Our major source of support is through individual and members donation and contribution.
                </p>
               
             </div>



      <!--==== DESCRIPTION ENDS=====--->



      <!-- === new about test start-->
      <div class="row">
    <div class="col-sm-6">
      
      <div class="container">
  <h2>Carousel Example</h2>  
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="assets/img/WPCI.jpg" alt="Los Angeles" style="width:100%;">
      </div>

      <div class="item">
        <img src="assets/img/wpci1.jpg" alt="Chicago" style="width:100%;">
      </div>
    
      <div class="item">
        <img src="assets/img/wpci2.jpg" alt="New york" style="width:100%;">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
    </div>
    <div class="col-sm-6">

     <!-- ======= F.A.Q Section ======= -->
    <section id="faq" class="faq">
      <div class="container">

        </div>

        <div class="faq-list" data-aos="zoom-in">
          <h2>ABOUT US</h2>
        
          <p style="text-align: justify; margin: 5px; font-size: 14px;">WPCI .org is a community based organization (CBO) and it’s proven with its conviction of lending essential projects to transform many lives of women and youths in the community. Lastly we ensure welfare and life span of mothers and youths in the community by educating them to prevent and avoid effective deeds. Therefore, WPCI is hereby to stand firm to support and work to save and strength community.</p>
        </div>

        <div class="faq-list">
          <ul>
            <li data-aos="fade-up">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" class="collapse" data-bs-target="#faq-list-1">OUR VISION<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-1" class="collapse show" data-bs-parent=".faq-list">
                <p style="font-size: 14px;">
                  No mother or youth nor infant has to suffer and die in life but to live under welfare of women program for counsel initiative WPCI.org 
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="100">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-2" class="collapsed">OUR MISSION? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-2" class="collapse" data-bs-parent=".faq-list">
                <p style="font-size: 14px;">
                 To maintain our advocacy of total safe pregnancy, delivery of safe children, as well as support breastfeeding mothers hence create women and youth’s empowerment projects in the society.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="200">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-3" class="collapsed">OUR GOALS AND OBJECTIVES <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-3" class="collapse" data-bs-parent=".faq-list">
                <p style="font-size: 14px;">
                 The below aims and objectives are meant to suite the mission of Women Program for Counsel Initiative (WPCI .org): -
                </p>
                <ul style="font-size: 14px;">
                  <li> To avoid unwanted pregnancy and trial marriage whereas to minimize girl child suffering and dead.</li>
                  <li>To create awareness and promote girl child education in order to fight illiteracy and ignorant in the society.</li>
                  <li> WPCI wants to decrease suffering and mortality rate of mothers, girl child, infants and youths in the community through improved health services, advice and supports.</li>
                  <li>To improve on diets of breastfeeding mothers and girl child in order to gain body immune and to ensure good health status.</li>
                  <li> To minimize irresponsible and immoral practices such as abortion, consumption of harmful drugs as well as drug addiction, drug misuse and sexual gender based violence. Through creation of sensitized programs and awareness.</li>
                  <li> WPCI, want to empower women and youths in the community in order to foster development through trainings on basic skills and knowledge.</li>
                  <li> To create employment opportunities and job division to citizens in the field of work career and profession in order to established co-economy standard and enhance development. </li>
                  <li> To create and promote social sensitize services and programs like training and caution on effects of immorality in order to avoid and fight unnecessary dead of mothers, girl child, infants and youths.</li>
                  <li> There is need to inspire mothers and youths on social activities of livelihood in order to sustain living and increase life expectancy by giving support and training.</li>
                  <li> To train active and strong youths and able leaders to ensure peaceful community. </li>
                  <li>Furthermore, there is need to minimize birth of abnormal, death as well as mental disordered and disable babies/children in the community.</li>
                  <li>To change the mindset of women and girls that they are weak and anyone can cheat on them or use their disadvantage.</li>
                </ul>
              </div>
            </li>

          

          </ul>
        </div>

      </div>
    </section><!-- End F.A.Q Section -->

    </div>
   
  </div>
      <!-- === new about test start-->


    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us">
      <div class="container">

        <div class="section-title" data-aos="zoom-in">
          <h2>Why Us</h2>
          <h3> <span>choose us because we have an excellent working Principles and Co- Values</span>?</h3>
          <p style="font-size: 14px;"> The Following are some of the the moral rules strong belief that influence our action and operation: -</p>
        </div>

        <div class="row">

          <div class="col-lg-4">
            <div class="box" data-aos="fade-up">
              <span></span>
              <h4> Counseling</h4>
              <p>these are the services offered to people inform of guidance and support to create a positive impact in them mostly</p>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0">
            <div class="box" data-aos="fade-up" data-aos-delay="100">
              <span></span>
              <h4>Awareness</h4>
              <p>this is an act of knowing about something that is in an existence or pending and its revealed and it can be a problem or an idea i.e. pregnant woman need to be aware on dangers of drug abuse to pregnancy and health.</p>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
              <span></span>
              <h4>Peace building</h4>
              <p>this program brings unit and sense of belonging to one another at work place and workshops.</p>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="box" data-aos="fade-up">
              <span></span>
              <h4> Development</h4>
              <p>this is a fundamental change in someone or in an environment which is positive and essential through employments and support such as training, awareness, ideas and skill to with-stand challenging factors.</p>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0">
            <div class="box" data-aos="fade-up" data-aos-delay="100">
              <span></span>
              <h4>Health care and service; </h4>
              <p>this can be in terms of creating awareness a caution about dangers which is harmful to health and ensure welfare.</p>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
              <span></span>
              <h4>Tolerance</h4>
              <p>; we are here to give rights, voice and see activities as part of participation of pregnant women and girl child in the society.</p>
            </div>
          </div>
          <div class="box">
              <span></span>
              <h4>Creation and division of job opportunities; </h4>
              <p>by this we offer women and girls high chance in regardless of their qualification.</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Why Us Section -->

    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts">
      <div class="container">

        <div class="row counters" style="text-align: justify; font-size: 17px; font-weight: bold;">
          <p>OUR VALES</p>

          <div class="col-lg-3 col-6 text-center">
           <!-- <span data-purecounter-start="0" data-purecounter-end="" data-purecounter-duration="1" class="purecounter"></span> -->
            <p>Integrity</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <!-- <span data-purecounter-start="0" data-purecounter-end="" data-purecounter-duration="1" class="purecounter"></span> -->
            <p>Allegiance</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
           <!-- <span data-purecounter-start="0" data-purecounter-end="" data-purecounter-duration="1" class="purecounter"></span> -->
            <p>Team workt</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
           <!-- <span data-purecounter-start="0" data-purecounter-end="" data-purecounter-duration="1" class="purecounter"></span> -->
            <p>Transparency</p>
          </div>
          <div class="col-lg-3 col-6 text-center">
           <!-- <span data-purecounter-start="0" data-purecounter-end="" data-purecounter-duration="1" class="purecounter"></span> -->
            <p>Compassion</p>
          </div>
          <div class="col-lg-3 col-6 text-center">
            <!-- <span data-purecounter-start="0" data-purecounter-end="" data-purecounter-duration="1" class="purecounter"></span> -->
            <p>Innovation</p>
          </div>
          <div class="col-lg-3 col-6 text-center">
            <!-- <span data-purecounter-start="0" data-purecounter-end="" data-purecounter-duration="1" class="purecounter"></span> -->
            <p>Accountability</p>
          </div>
          
          <div class="col-lg-3 col-6 text-center">
            <!-- <span data-purecounter-start="0" data-purecounter-end="" data-purecounter-duration="1" class="purecounter"></span> -->
            <p>Professionalism & <br> Self-motivation</p>
          </div>
        
        </div>

      </div>
    </section><!-- End Counts Section -->

    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
      <div class="container" data-aos="zoom-in">

        <div class="text-center">
          <h3>Call To Action</h3>
          <p> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
          <a class="cta-btn" href="#">Call To Action</a>
        </div>

      </div>
    </section><!-- End Cta Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="section-title" data-aos="zoom-in">
          <h2>Services</h2>
          <h3>Our Awesome <span>Services</span></h3>
          <p></p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="icon-box" data-aos="zoom-in">
              <div class="icon"></i></div>
              <h4><a href="">Counseling and guidance</a></h4>
              <p></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="100">
              <div class="icon"></div>
              <h4><a href="">  Health care & Nutrition</a></h4>
              <p></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="200">
              <div class="icon"></div>
              <h4><a href=""> Food Security & Livelihood</a></h4>
              <p></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="300">
              <div class="icon"></div>
              <h4><a href="">  Child protection & GBV </a></h4>
              <p></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="400">
              <div class="icon"></div>
              <h4><a href="">Sex & formal Education</a></h4>
              <p></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4">
            <div class="icon-box" data-aos="zoom-in" data-aos-delay="500">
              <div class="icon"></i></div>
              <h4><a href=""> Women and Youths Empowerment</a></h4>
              <p></p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->

   

    <!-- ======= Team Section ======= -->
    <section id="team" class="team">
      <div class="container">

        <div class="section-title" data-aos="zoom-in">
          <h2>Team</h2>
          <h3>Our Hard Working <span>Team</span></h3>
          <p>Ut possimus qui ut temporibus culpa velit eveniet modi omnis est adipisci expedita at voluptas atque vitae autem.</p>
        </div>

        <div class="row">

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up">
              <div class="member-img">
                <img src="assets/img/ed1.jpeg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Yousif Musa John</h4>
                <span>Executive Director</span>
                <span>+21191982453</span>
                <span>yousifmusawpci@gmail.com</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="100">
              <div class="member-img">
                <img src="assets/img/ed.png" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Syliverster Brown</h4>
                <span>Finance Officer</span>
                <span>+211921155030</span>
                <span>sylvesterbrown478@gmail.com</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="200">
              <div class="member-img">
                <img src="assets/img/ed2.jpeg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Diana Doroka</h4>
                <span>Program Coordinator</span>
                <span>+211925819964</span>
                <span>kennethdiana@gmail.com</span>

              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
            <div class="member" data-aos="fade-up" data-aos-delay="300">
              <div class="member-img">
                <img src="assets/img/amin.jpeg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Aminton T Hillary</h4>
                <span>Asstant Information Officer</span>
                <span>+256779590003</span>
                <span>amintonhillary@gmail</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Team Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container">

        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-item">
               
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                 
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="assets/img/ed1.jpeg" class="testimonial-img" alt="">
                <h3>Yousif Musa John</h3>
                <h4>Excutive Director</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                   Women program for Counsel initiative. Non governmental organization
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="assets/img/ed.png" class="testimonial-img" alt="">
                <h3>Sylvester Brown/h3>
                <h4>Finance Officer</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  Women program for Counsel initiative. Non governmental organization
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="assets/img/ed2.jpeg" class="testimonial-img" alt="">
                <h3>Diana Doroka</h3>
                <h4>Program Coordinator</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                   Women program for Counsel initiative. Non governmental organization
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="assets/img/amin.jpeg" class="testimonial-img" alt="">
                <h3>Aminton T Hillary</h3>
                <h4>Assitant Information  officer</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  Women program for Counsel initiative. Non governmental organization
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

   
   

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title" data-aos="zoom-in">
          <h2>Contact</h2>
          <h3>Check our <span>Contact</span> Details</h3>
          <p>Ut possimus qui ut temporibus culpa velit eveniet modi omnis est adipisci expedita at voluptas atque vitae autem.</p>
        </div>

        <div>
          <iframe style="border:0; width: 100%; height: 270px;" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" allowfullscreen></iframe>
        </div>

        <div class="row mt-5">

          <div class="col-lg-4" data-aos="fade-right">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Location:</h4>
                <p>A108 Adam Street, New York, NY 535022</p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p>info@example.com</p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Call:</h4>
                <p>+1 5589 55488 55s</p>
              </div>

            </div>

          </div>

          <div class="col-lg-8 mt-5 mt-lg-0" data-aos="fade-left">

            <form action="https://formsubmit.co/wpcisouthsudan106@gmail.com" method="POST">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>

          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">

      <div class="container">

        <div class="row  justify-content-center">
          <div class="col-lg-6">
            <h3>Remember</h3>
            <p>Et aut eum quis fuga eos sunt ipsa nihil. Labore corporis magni eligendi fuga maxime saepe commodi placeat.</p>
          </div>
        </div>

        <div class="row footer-newsletter justify-content-center">
          <div class="col-lg-6">
            <form action="" method="post">
              <input type="email" name="email" placeholder="Enter your Email"><input type="submit" value="Subscribe">
            </form>
          </div>
        </div>

        <div class="social-links">
          <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
          <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>

      </div>
    </div>

    <div class="container footer-bottom clearfix">
      <div class="copyright">
        &copy; Copyright <strong><span>Remember</span></strong>. All Rights Reserved
      </div>
      <div>
        <a href="https://earth.google.com/web/@4.86906088,31.53403159,479.86960543a,682.0319655d,35y,0h,0t,0r/data=OgMKATA"> Location</a>
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/remember-free-multipurpose-bootstrap-template/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>